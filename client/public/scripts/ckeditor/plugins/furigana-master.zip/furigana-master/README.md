# furigana
This is a tool furigana for ckeditor 4
You can download ckeditor 4 at : https://ckeditor.com/ckeditor-4/download/
after download ckeditor 4 you must copy : folder 'furigana' in to 'plugins' folder ckeditor

edit config.js add two line :
config.allowedContent = true;
config.extraPlugins = 'furigana';

demo :
![Demo](https://github.com/tygonorg/furigana/blob/master/screen.gif?raw=true)
